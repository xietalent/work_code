from scrapy import cmdline
cmdline.execute('scrapy crawl DouBan --nolog'.split())
