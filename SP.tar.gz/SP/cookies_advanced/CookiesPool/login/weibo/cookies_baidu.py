import time
from os.path import abspath, dirname

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

TEMPLATES_FOLDER = dirname(abspath(__file__)) + '/templates/'


class BaiduCookies():
    def __init__(self, username, password, browser):
        self.url = 'http://wappass.baidu.com/passport/?login&tpl=wimn&subpro=wimn&regtype=1&u=https%3A%2F%2Fm.baidu.com/usrprofile%23logined'
        self.browser = browser
        self.wait = WebDriverWait(self.browser, 20)
        self.username = username
        self.password = password

    def open(self):
        """
        打开网页输入用户名密码并点击
        :return: None
        """
        self.browser.delete_all_cookies()
        self.browser.get(self.url)

        # 找到用户名密码和登录的 按钮
        username = self.wait.until(EC.presence_of_element_located((By.ID, 'login-username')))
        password = self.wait.until(EC.presence_of_element_located((By.ID, 'login-password')))

        # 向用户名，密码中设置数据
        username.send_keys(self.username)
        password.send_keys(self.password)

        submit = self.wait.until(EC.element_to_be_clickable((By.ID, 'login-submit')))
        time.sleep(1)
        submit.click()

    def get_cookies(self):
        """
        获取Cookies
        :return:
        """
        return self.browser.get_cookies()

    def main(self):
        """
        破解入口
        :return:
        """
        self.open()

        time.sleep(30)

        return {"status": 1, "content": self.get_cookies()}

        # if self.password_error():
        #     return {
        #         'status': 2,
        #         'content': '用户名或密码错误'
        #     }
        # # 如果不需要验证码直接登录成功
        # if self.login_successfully():
        #     cookies = self.get_cookies()
        #     return {
        #         'status': 1,
        #         'content': cookies
        #     }


if __name__ == '__main__':
    result = BaiduCookies('18511287795', 'Rock1204', webdriver.Chrome("/home/rock/Desktop/SP/cookies_advanced/CookiesPool/chromedriver")).main()
    print(result)
